//
//  main.m
//  Programa 3-4 - Programa para acessar variáveis de instância - continuação
//
//  Created by Marcos Artur da Costa Cabral Filho on 03/01/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

//---- seção @interface ----

@interface Fraction: NSObject

//-(void) print;
-(void) setNumerator: (int) n;
-(void) setDenominator: (int) d;
-(int) numerator;
-(int) denominator;

@end

//---- seção @implementation ----

@implementation Fraction
{
    int numerator;
    int denominator;
}

/*
-(void) print
{
    NSLog (@"%i/%i", numerator, denominator);
}
*/

-(void) setNumerator: (int) n
{
    numerator = n;
}

-(void) setDenominator: (int) d
{
    denominator = d;
}

-(int) numerator
{
    return numerator;
}

-(int) denominator
{
    return denominator;
}

@end

//---- seção de programa ----

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        
        Fraction *myFraction = [[Fraction alloc] init];
        
        // Define a fração como 1/3
        
        [myFraction setNumerator: 1];
        [myFraction setDenominator: 3];
        
        // Exibe a fração usando nossos dois novos métodos
        
        NSLog (@"The value of my Fraction is: %i/%i",
        [myFraction numerator], [myFraction denominator]);
    }
    return 0;
}
