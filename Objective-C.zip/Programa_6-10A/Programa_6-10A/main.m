//
//  main.m
//  Programa_6-10A - Programa para gerar uma tabela de números primos
//  segunda versão, usando o tipo BOOL e valores predefinidos
//
//  Created by Marcos Artur da Costa Cabral Filho on 28/04/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        int p, d;
        BOOL isPrime;
        
        for ( p = 2; p <= 50; ++p ) {
            isPrime = YES;
            for ( d = 2; d < p; ++d )
                if ( p % d == 0 )
                    isPrime = NO;
            if ( isPrime == YES )
                NSLog(@"%i ", p);
        }
        
    }
    return 0;
}
