//
//  main.m
//  Exerc_5-8 - Programa para somar os dígitos de um número
//
//  Created by Marcos Artur da Costa Cabral Filho on 29/02/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        int number, right_digit, soma;
        
        NSLog(@"Enter your number.");
        scanf ("%i", &number);
        
        while ( number != 0 ) {
            right_digit = number % 10;
            soma += right_digit;
            number /= 10;
        }
        NSLog(@"A soma é igual a: %i", soma);
    }
    return 0;
}
