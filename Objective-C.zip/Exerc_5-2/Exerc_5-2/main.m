//
//  main.m
//  Exerc_5-2 Tabela de números triangulares
//
//  Created by Marcos Artur da Costa Cabral Filho on 29/02/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        int n, triangularNumber;
        
        for ( n = 5; n <= 50; n = n + 5 ) {
            triangularNumber = n * (n + 1) / 2;
            NSLog(@"%2i  %3i", n, triangularNumber);
        }
    }
    return 0;
}
