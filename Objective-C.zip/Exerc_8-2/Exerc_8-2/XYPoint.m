//
//  XYPoint.m
//  Exerc_8-2
//
//  Created by Marcos Artur da Costa Cabral Filho on 26/03/17.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import "XYPoint.h"

@implementation XYPoint

@synthesize x, y;

-(void) setX: (float) xVal andY: (float) yVal
{
    x = xVal;
    y = yVal;
}
@end
