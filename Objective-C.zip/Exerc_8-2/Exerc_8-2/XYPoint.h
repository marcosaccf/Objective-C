//
//  XYPoint.h
//  Exerc_8-2
//
//  Created by Marcos Artur da Costa Cabral Filho on 26/03/17.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XYPoint : NSObject

@property float x, y;

-(void) setX: (float) xVal andY: (float) Yval;

@end
