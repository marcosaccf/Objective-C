//
//  Rectangle.m
//  Exerc_8-2
//
//  Created by Marcos Artur da Costa Cabral Filho on 26/03/17.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import "Rectangle.h"

@implementation Rectangle
{
    XYPoint *origin;
}

@synthesize width, height;

-(void) setWidth: (float) w andHeight: (float) h
{
    width = w;
    height = h;
}

-(void) setOrigin: (XYPoint *) pt
{
    if (! origin)
        origin = [[XYPoint alloc] init];
    
    origin.x = pt.x;
    origin.y = pt.y;
}

-(float) area
{
    return width * height;
}

-(float) perimeter
{
    return (width + height) * 2;
}

-(XYPoint *) origin
{
    return origin;
}
@end
