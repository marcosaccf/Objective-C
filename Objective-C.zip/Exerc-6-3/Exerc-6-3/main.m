//
//  main.m
//  Exerc-6-3
//
//  Created by Marcos Artur da Costa Cabral Filho on 29/04/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Fraction: NSObject

-(void)     print;
-(void)     setNumerator:   (int) n;
-(void)     setDenominator: (int) d;
-(int)      numerator;
-(int)      denominator;
-(double)   convertToNum;
@end

@implementation Fraction
{
    int numerator;
    int denominator;
}

-(void) print
{
    if ( denominator == 1 )
        NSLog(@" %i ", numerator);
    else if ( numerator == 0 )
        NSLog(@" 0 ");
    else
        NSLog(@" %i/%i ", numerator, denominator);
}

-(void) setNumerator: (int) n
{
    numerator = n;
}

-(void) setDenominator: (int) d
{
    denominator = d;
}

-(int) numerator
{
    return numerator;
}

-(int) denominator
{
    return denominator;
}

-(double) convertToNum
{
    if (denominator != 0)
        return (double) numerator / denominator;
    else
        return NAN;
}
@end

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        
        Fraction *aFraction = [[Fraction alloc] init];
        Fraction *bFraction = [[Fraction alloc] init];
        
        [aFraction setNumerator: 1];    // a 1ª fração é 1/4
        [aFraction setDenominator: 4];
        
        [aFraction print];
        NSLog(@" =");
        NSLog(@"%g", [aFraction convertToNum]);
        
        [bFraction print];      // nunca é atribuído um valor
        NSLog(@" =");
        NSLog(@"%g", [bFraction convertToNum]);
    }
    return 0;
}
