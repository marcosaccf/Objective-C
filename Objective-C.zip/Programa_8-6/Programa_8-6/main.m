//
//  main.m
//  Programa_8-6 - Anulando métodos
//
//  Created by Marcos Artur da Costa Cabral Filho on 20/02/17.
//  Copyright © 2017 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

// Declaração e definição de ClassA

@interface ClassA: NSObject
{
    int x; // Será herdado pelas subclasses
}

-(void) initVar;
@end

//////////////////////////

@implementation ClassA
-(void) initVar
{
    x = 100;
}
@end

// Declaração e definição de ClassB

@interface ClassB: ClassA
-(void) initVar;
-(void) printVar;
@end

//////////////////////////

@implementation ClassB
-(void) initVar // método adicionado
{
    x = 200;
}

-(void) printVar
{
    NSLog (@"x = %i", x);
}
@end

//////////////////////////

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        ClassB *b = [[ClassB alloc] init];
        
        [b initVar]; // usa anulação de método em B
        
        [b printVar]; // revela o valor de x
    }
    return 0;
}
