//
//  main.m
//  Programa 4-1
//
//  Created by Marcos Artur da Costa Cabral Filho on 05/01/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        int integerVar = 100;
        float floatingVar = 331.79;
        double doubleVar = 8.44e+11;
        char charVar = 'W';
        NSLog(@"intergerVar = %i", integerVar);
        NSLog(@"floatingVar = %f", floatingVar);
        NSLog(@"doubleVar = %e", doubleVar);
        NSLog(@"doublevar = %g", doubleVar);
        NSLog(@"charVar = %c", charVar);
    }
    return 0;
}
