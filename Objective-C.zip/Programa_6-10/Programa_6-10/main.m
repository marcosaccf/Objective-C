//
//  main.m
//  Programa_6-10 - Programa para gerar uma tabela de números primos
//
//  Created by Marcos Artur da Costa Cabral Filho on 25/04/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        int p, d, isPrime;
        
        for ( p = 2; p <= 50; ++p ) {
            isPrime = 1;
            for ( d = 2; d < p; ++d )
                if ( p % d == 0 )
                    isPrime = 0;
            
            if ( isPrime )
                NSLog(@"%i ", p);
        }
    }
    return 0;
}
