//
//  main.m
//  Programa_6-6 - Programa para implementar a função de sinal
//
//  Created by Marcos Artur da Costa Cabral Filho on 12/04/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        int number, sign;
        
        NSLog(@"Please type in a number: ");
        scanf ("%i", &number);
        
        if ( number < 0 )
            sign = -1;
        else if ( number == 0 )
            sign = 0;
        else    // Deve ser positivo
            sign = 1;
        
        NSLog (@"Sign = %i", sign);
    }
    return 0;
}
