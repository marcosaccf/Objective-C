//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground";
var string2 : String = "The winter is coming!" // String é o tipo utilizado para representar textos, um conjunto de caracteres
var numeroInteiro = 42
// numeroInteiro = "teste"
var numeroInteiro2 : Int = 10 // Int é o tipo usado para representar números inteiros
var soma = numeroInteiro + numeroInteiro2
var numeroDecimal = 1.2
var numeroDecimal2 : Double = 22.4 // Double é o tipo usado para representar numeros decimais
var soma2 = Double(numeroInteiro) + numeroDecimal
var ligado = true
var fechado : Bool = false
let stringConstante = "Winterfell"

// stringConstante = "Starks"
