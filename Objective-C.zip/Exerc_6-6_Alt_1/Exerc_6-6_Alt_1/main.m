//
//  main.m - NÃO FUNCIONA COM NEGATIVO!
//  Ex.Ch.6
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{
    
    @autoreleasepool {
        
        int n, leftDigit, number;
        
        NSLog(@"Enter number:");
        scanf("%20d", &number);
        /*This assigns the number of digits to 20. You could define number as float and write %f instead as discussed above.*/
        
        if(number == 0)
            NSLog(@"zero");
        else
        {
            n = log10f(number);
            
            do
            {
                
                leftDigit = number / pow(10, n);
                
                
                switch(leftDigit)
                {
                    case 0:
                        NSLog(@"zero");
                        number = number - (leftDigit * pow(10,n));
                        break;
                    case 1:
                        NSLog(@"one");
                        number = number - (leftDigit * pow(10,n));
                        break;
                    case 2:
                        NSLog(@"two");
                        number = number - (leftDigit * pow(10,n));
                        break;
                    case 3:
                        NSLog(@"three");
                        number = number - (leftDigit * pow(10,n));
                        break;
                    case 4:
                        NSLog(@"four");
                        number = number - (leftDigit * pow(10,n));
                        break;
                    case 5:
                        NSLog(@"five");
                        number = number - (leftDigit * pow(10,n));
                        break;
                    case 6:
                        NSLog(@"six");
                        number = number - (leftDigit * pow(10,n));
                        break;
                    case 7:
                        NSLog(@"seven");
                        number = number - (leftDigit * pow(10,n));
                        break;
                    case 8:
                        NSLog(@"eight");
                        number = number - (leftDigit * pow(10,n));
                        break;
                    case 9:
                        NSLog(@"nine");
                        number = number - (leftDigit * pow(10,n));
                        break;
                }
                --n;
            }
            while(n >= 0);
        }
    }
    return 0;
}
