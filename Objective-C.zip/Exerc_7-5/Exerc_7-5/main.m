//
//  main.m
//  Exerc_7-5 - Implementa uma classe Complex com o método add
//
//  Created by Marcos Artur da Costa Cabral Filho on 24/09/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

//---- seção @interface ----

@interface Complex: NSObject

@property double real, imaginary;

-(void) setR: (double) r im: (double) i;
-(void) print;
-(Complex *) add: (Complex *) complexNum;

@end

//---- seção @implementation ----

@implementation Complex

@synthesize real, imaginary;

-(void) print
{
    printf("(%g + %gi)", real, imaginary);
}

-(void) setR: (double) r im: (double) i
{
    real = r;
    imaginary = i;
}

-(Complex *) add: (Complex *) complexNum
{
    // Para somar dois números complexos
    // (a + bi) + (c + di) = (a + c) + (b + d)i
    Complex *result = [[Complex alloc] init];
    result = complexNum;
    result.real += real;
    result.imaginary += imaginary;
    return result;
}

@end

//---- seção de programa ----

int main(int argc, const char * argv[])
{
    @autoreleasepool {
        Complex *aComplex = [[Complex alloc] init];
        Complex *bComplex = [[Complex alloc] init];
        Complex *result;
        
        [aComplex setR: 5.3 im: 7];
        [bComplex setR: 2.7 im: 4];
        [aComplex print];
        printf(" + ");
        [bComplex print];
        printf(" = ");
        
        result = [aComplex add: bComplex];
        [result print];
        printf("\n");
    }
    return 0;
}
