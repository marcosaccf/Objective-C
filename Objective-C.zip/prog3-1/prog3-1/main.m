//
//  main.m
//  prog3-1 - Programa simples para trabalhar com frações
//
//  Created by Marcos Artur da Costa Cabral Filho on 08/12/15.
//  Copyright © 2015 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        int numerator = 1;
        int denominator = 3;
        NSLog(@"The fraction is %i/%i", numerator, denominator);
    }
    return 0;
}
