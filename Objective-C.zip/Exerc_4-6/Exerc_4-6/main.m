//
//  main.m
//  Exerc_4-6 - Implementa uma classe Complex
//
//  Created by Marcos Artur da Costa Cabral Filho on 15/01/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

//---- seção @interface ----

@interface Complex: NSObject

-(void) setReal: (double) a;
-(void) setImaginary: (double) b;
-(void) print;  // exibe como a + bi
-(double) real;
-(double) imaginary;

@end

//---- seção @implementation ----

@implementation Complex
{
    double real;
    double imaginary;
}

-(void) print
{
    NSLog (@"%g + %gi", real, imaginary);
}

-(void) setReal:(double) a
{
    real = a;
}

-(void) setImaginary:(double) b
{
    imaginary = b;
}

-(double) real
{
    return real;
}

-(double) imaginary
{
    return imaginary;
}

@end

//---- seção de programa ----

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Complex *myComplex = [[Complex alloc] init];
        
        [myComplex setReal: 2.0];
        [myComplex setImaginary: 4.0];
        
        // Exibe o complexo usando o método print
        NSLog(@"O número complexo é:");
        [myComplex print];
        
        [myComplex setReal: 5.0];
        [myComplex setImaginary: 10.0];
        
        // Exibe o complexo usando os métodos real e imaginary
        NSLog (@"O novo número complexo é:");
        NSLog (@"%g + %gi", [myComplex real], [myComplex imaginary]);
    }
    return 0;
}
