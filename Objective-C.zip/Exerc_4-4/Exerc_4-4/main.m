//
//  main.m
//  Exerc_4-4
//
//  Created by Marcos Artur da Costa Cabral Filho on 07/01/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        float x = 2.55;
        float result;
        
        result = 3 * x * x * x - 5 * x * x + 6;
        NSLog (@"O resultado de 3xˆ3 - 5xˆ2 + 6, com x = 2.55 é: %f", result);
    }
    return 0;
}
