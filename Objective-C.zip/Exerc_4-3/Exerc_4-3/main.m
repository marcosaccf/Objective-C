//
//  main.m
//  Exerc_4-3
//
//  Created by Marcos Artur da Costa Cabral Filho on 07/01/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        char c, d;
        
        c = 'd';
        d = c;
        NSLog (@"d = %c", d);
    }
    return 0;
}
