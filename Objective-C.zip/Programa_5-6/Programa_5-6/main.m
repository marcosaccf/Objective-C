//
//  main.m
//  Programa_5-6 - Este programa introduz a instrução while
//
//  Created by Marcos Artur da Costa Cabral Filho on 29/02/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        int count = 1;
        
        while ( count <= 5 ) {
            NSLog(@"%i", count);
            ++count;
        }
    }
    return 0;
}
