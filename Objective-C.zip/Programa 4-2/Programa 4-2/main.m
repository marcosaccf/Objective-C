//
//  main.m
//  Programa 4-2 - Ilustra o uso de vários operadores aritméticos
//
//  Created by Marcos Artur da Costa Cabral Filho on 07/01/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        int a = 100;
        int b = 2;
        int c = 25;
        int d = 4;
        int result;
        
        result = a - b;     // subtração
        NSLog(@"a - b = %i", result);
        
        result = b * c;     // multiplicação
        NSLog(@"b * c = %i", result);
        
        result = a / c;     // divisão
        NSLog(@"a / c = %i", result);
        
        result = a + b * c; // precedência
        NSLog(@"a + b * c = %i", result);
        
        NSLog(@"a * b + c * d = %i", a * b + c * d);
    }
    return 0;
}
