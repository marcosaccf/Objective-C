//: Playground - noun: a place where people can play

// Comandos básicos em Swift

var poder = 9000

if poder > 8000 {
    print("É mais de oito mil!!!")
} else {
    print("menor ou igual a 8000")
}

if (poder == 9000) {
    print("É nove mil")
}

for var esfera=1; esfera<=7; esfera++ {
    print(esfera)
}

for esfera in 1...7 {
    print(esfera)
}

var esferasAchadas = 0
switch