//
//  main.m
//  Exerc_5-1 - Programa para gerar tabela n e n2
//
//  Created by Marcos Artur da Costa Cabral Filho on 29/02/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        int n, n2;
        
        NSLog (@" n   n2");
        NSLog (@"-------");
        
        for (n = 1; n <= 10; ++n) {
            n2 = n * n;
            NSLog (@"%2i  %3i", n, n2);
        }
    }
    return 0;
}
