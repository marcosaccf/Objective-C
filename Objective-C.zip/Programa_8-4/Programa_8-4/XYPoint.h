//
//  XYPoint.h
//  Programa_8-4
//
//  Created by Marcos Artur da Costa Cabral Filho on 24/09/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XYPoint : NSObject

@property int x, y;

-(void) setX: (int) xVal andY: (int) Yval;

@end
