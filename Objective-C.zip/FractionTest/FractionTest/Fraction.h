//
//  Fraction.h
//  FractionTest
//
//  Created by Marcos Artur da Costa Cabral Filho on 03/09/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

// Define a classe Fraction

@interface Fraction : NSObject

@property int numerator, denominator;

-(void)         print;
-(void)         setTo: (int) n over: (int) d;
-(double)       convertToNum;
-(Fraction *)   add: (Fraction *) f;
-(void)         reduce;
@end
