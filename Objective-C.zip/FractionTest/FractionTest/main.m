//
//  main.m
//  FractionTest
//
//  Created by Marcos Artur da Costa Cabral Filho on 01/05/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import "Fraction.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Fraction *aFraction = [[Fraction alloc] init];
        Fraction *bFraction = [[Fraction alloc] init];
        
        Fraction *resultFraction;
        
        // Define duas frações como 1/4 e 1/2 e as soma
        
        [aFraction setTo: 1 over: 4]; // define a 1a. fração como 1/4
        [bFraction setTo: 1 over: 2]; // define a 2a. fração como 1/2
        
        // Imprime os resultados
        
        [aFraction print];
        NSLog (@"+");
        [bFraction print];
        NSLog(@"=");
        
        resultFraction = [aFraction add: bFraction];
        
        // reduz o resultado da adição e o imprime
        
        [resultFraction print];
    }
    
    return 0;
}
