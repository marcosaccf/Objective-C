//
//  main.m
//  Exerc_4-7 - definição de uma classe Rectangle
//
//  Created by Marcos Artur da Costa Cabral Filho on 15/01/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Rectangle: NSObject
-(void) setWidth: (int) w;
-(void) setHeight: (int) h;
-(int) width;
-(int) height;
-(int) area;
-(int) perimeter;
@end

@implementation Rectangle
{
    int width;
    int height;
    int area;
    int perimeter;
}

-(void) setWidth: (int) w
{
    width = w;
}

-(void) setHeight: (int) h
{
    height = h;
}

-(int) width
{
    return width;
}

-(int) height
{
    return height;
}

-(int) area
{
    area = width * height;
    return area;
}

-(int) perimeter
{
    perimeter = 2 * (width + height);
    return perimeter;
}
@end


int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Rectangle *myRectangle = [[Rectangle alloc] init];
        [myRectangle setWidth: 10];
        [myRectangle setHeight: 15];
        NSLog(@"A largura é %i; a altura é %i; a área é %i; o perímetro é %i.", [myRectangle width], [myRectangle height], [myRectangle area], [myRectangle perimeter]);
    }
    return 0;
}
