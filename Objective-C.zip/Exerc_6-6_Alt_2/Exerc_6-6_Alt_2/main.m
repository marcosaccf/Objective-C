#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{
    @autoreleasepool
    {
        int number, right_digit, count = 0, number_reversed = 0;
        
        printf("Enter a number: ");
        scanf("%d", &number); // The %d conversion specifier prevents octal input (i.e. 010 = 8)
        
        if (number < 0)
        {
            number = -number; // added this for a minus number
            printf("minus\n");
        }
        // reverse the number and count how many digits to print.
        
        while (number != 0)
        {
            right_digit = number % 10;
            number_reversed = number_reversed * 10 + right_digit;
            ++count;
            number /= 10;
        }
        
        do // need to make at least one pass if zero is entered.
        {
            right_digit = number_reversed % 10;
            
            switch (right_digit)
            {
                case 0:
                    printf("zero\n");
                    break;
                    
                case 1:
                    printf("one\n");
                    break;
                    
                case 2:
                    printf("two\n");
                    break;
                    
                case 3:
                    printf("three\n");
                    break;
                    
                case 4:
                    printf("four\n");
                    break;
                    
                case 5:
                    printf("five\n");
                    break;
                    
                case 6:
                    printf("six\n");
                    break;
                    
                case 7:
                    printf("seven\n");
                    break;
                    
                case 8:
                    printf("eight\n");
                    break;
                    
                case 9:
                    printf("nine\n");
                    break;
                    
                default:
                    printf("Unknown input");
                    break;
            }
            number_reversed /= 10;
            --count;
        } while (count > 0); // prevents an entry of 0 from keeping the do statement running ( count == -1)
        
    }
    return 0;
}