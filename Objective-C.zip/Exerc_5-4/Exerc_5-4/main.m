//
//  main.m
//  Programa_5-3 - Programa para gerar uma tabela de números triangulares
//
//  Created by Marcos Artur da Costa Cabral Filho on 28/02/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        int n, triangularNumber;
        
        NSLog (@"TABLE OF TRIANGULAR NUMBERS");
        NSLog (@" n Sum from 1 to n");
        NSLog (@"-- ---------------");
        
        triangularNumber = 0;
        
        for ( n = 1; n <= 10; ++n) {
            triangularNumber += n;
            NSLog (@"%-2i       %i", n, triangularNumber);
        }
    }
    return 0;
}
