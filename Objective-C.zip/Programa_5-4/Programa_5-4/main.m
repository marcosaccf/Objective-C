//
//  main.m
//  Programa_5-4
//
//  Created by Marcos Artur da Costa Cabral Filho on 28/02/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        int n, number, triangularNumber;
        NSLog(@"What triangular number do you want?");
        scanf ("%i", &number);
        
        triangularNumber= 0;
        
        for ( n = 1; n <= number; ++n )
            triangularNumber += n;
        NSLog(@"Trianguar number %i is %i\n", number, triangularNumber);
    }
    return 0;
}
