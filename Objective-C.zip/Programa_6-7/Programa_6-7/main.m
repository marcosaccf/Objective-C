//
//  main.m
//  Programa_6-7 - Este programa classifica um único caractere
//                  digitado no teclado
//
//  Created by Marcos Artur da Costa Cabral Filho on 12/04/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        char c;
        
        NSLog(@"Enter a single character:");
        scanf (" %c", &c);
        
        if ( (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') )
            NSLog (@"It's an alphabetic character.");
        else if ( c >= '0' && c <= '9' )
            NSLog (@"It's a digit.");
        else
            NSLog (@"It's a special character.");
    }
    return 0;
}
