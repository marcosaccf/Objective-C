//
//  main.m
//  Exerc_8-1
//
//  Created by Marcos Artur da Costa Cabral Filho on 20/02/17.
//  Copyright © 2017 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

// Declaração e definição de ClassA

@interface ClassA: NSObject
{
    int x;
}

-(void) initVar;
-(void) printVar;
@end

@implementation ClassA
-(void) initVar
{
    x = 100;
}
-(void) printVar;
{
    NSLog (@"x = %i", x);
}
@end

// Declaração e definição de ClassB

@interface ClassB: ClassA
-(void) printVar;
@end

@implementation ClassB
-(void) printVar;
{
    NSLog (@"x = %i", x);
}
@end

// Declaração e definição de ClassC

@interface ClassC: ClassB
-(void) initVar;
@end

@implementation ClassC
-(void) initVar
{
    x = 300;
}
@end

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        ClassA *a = [[ClassA alloc] init];
        ClassB *b = [[ClassB alloc] init];
        ClassC *c = [[ClassC alloc] init];
        
        [a initVar];    // usará método próprio
        [a printVar];   // revela o valor de x
        [b initVar];    // usará método herdado
        [b printVar];   // revela o valor de x
        [c initVar];    // usará método herdado
        [c printVar];   // revela o valor de x
    }
    return 0;
}
