//
//  Fraction.h
//  Exerc_7-1
//
//  Created by Marcos Artur da Costa Cabral Filho on 03/09/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

// Define a classe Fraction

@interface Fraction : NSObject

@property int numerator, denominator, redNumerator, redDenominator;

-(void)         print;
-(void)         setTo: (int) n over: (int) d;
-(double)       convertToNum;
-(Fraction *)   add: (Fraction *) f;
-(Fraction *)   subtract: (Fraction *) f;
-(Fraction *)   multiply: (Fraction *) f;
-(Fraction *)   divide: (Fraction *) f;
-(void)         reduce;

@end
