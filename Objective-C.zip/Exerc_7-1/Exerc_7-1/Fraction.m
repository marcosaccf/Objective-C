//
//  Fraction.m
//  Exerc_7-1
//
//  Created by Marcos Artur da Costa Cabral Filho on 03/09/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import "Fraction.h"

@implementation Fraction

@synthesize numerator, denominator, redNumerator, redDenominator;

bool reduzida;
int inteiro, newNumerator, newDenominator;

-(void) print
{
    if ((numerator > denominator) && (numerator % denominator != 0)) {
        inteiro = numerator / denominator;
        newNumerator = numerator % denominator;
        newDenominator = denominator;
        
        // reduz a fração mista
        
        int u = newNumerator;
        int v = newDenominator;
        int temp;
        
        while (v != 0) {
            temp = u % v;
            u = v;
            v = temp;
        }
        newNumerator /= u;
        newDenominator /= u;
        
        NSLog (@"%i %i/%i", inteiro, newNumerator, newDenominator);
    }
    else {
        
        if (reduzida == FALSE)
            NSLog (@"%i/%i", numerator, denominator);
        else {
            NSLog (@"%i/%i", numerator, denominator);
            NSLog (@"%i/%i (reduzida)", redNumerator, redDenominator);
        }
    }
    reduzida = FALSE;
}

-(double) convertToNum
{
    if (denominator != 0)
        return (double) numerator / denominator;
    else
        return NAN;
}

-(void) setTo: (int) n over: (int) d
{
    numerator = n;
    denominator = d;
}

// soma uma fração com o destinatário

-(Fraction *) add: (Fraction *) f
{
    // Para somar duas frações:
    // a/b + c/d = ((a*d) + (b*c)) / (b * d)
    
    // result armazenará o resultado da adição
    Fraction *result = [[Fraction alloc] init];
    
    result.numerator = numerator * f.denominator +
        denominator * f.numerator;
    result.denominator = denominator * f.denominator;
    
    [result reduce];
    return result;
}

-(Fraction *) subtract: (Fraction *) f
{
    // Para subtrair duas frações:
    // a/b - c/d = (((a*d - (b*c)) / (b*d)
    
    // result armazenará o resultado da adição
    Fraction *result = [[Fraction alloc] init];
    
    result.numerator = numerator * f.denominator -
    denominator * f.numerator;
    result.denominator = denominator * f.denominator;
    
    [result reduce];
    return result;
}

-(Fraction *) multiply: (Fraction *) f
{
    // Para multiplicar duas frações:
    // a/b * c/d = (a * c) / (b * d)
    
    // result armazenará o resultado da adição
    Fraction *result = [[Fraction alloc] init];
    
    result.numerator = numerator * f.numerator;
    result.denominator = denominator * f.denominator;
    
    [result reduce];
    return result;
}

-(Fraction *) divide: (Fraction *) f
{
    // Para dividir duas frações:
    // a/b / c/d = (a * d) / (b * c)
    
    // result armazenará o resultado da adição
    Fraction *result = [[Fraction alloc] init];
    
    result.numerator = numerator * f.denominator;
    result.denominator = denominator * f.numerator;
    
    [result reduce];
    return result;
}

-(void) reduce
{
    // Para reduzir a fração
    
    int u = numerator;
    int v = denominator;
    int temp;
    
    while (v != 0) {
        temp = u % v;
        u = v;
        v = temp;
    }
    redNumerator = numerator / u;
    redDenominator = denominator / u;
    if (redNumerator == numerator)
        reduzida = FALSE;
    else
        reduzida = TRUE;
}
@end
