//
//  main.m
//  Exerc_7-1
//
//  Created by Marcos Artur da Costa Cabral Filho on 03/09/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import "Fraction.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        
        Fraction *aFraction = [[Fraction alloc] init];
        Fraction *bFraction = [[Fraction alloc] init];
        
        Fraction *resultFraction;
        
        // Definindo das frações
        [aFraction setTo: 5 over: 3];
        [bFraction setTo: 4 over: 2];
        
        // Somando a 1a. com a 2a. fração
        [aFraction print];
        NSLog (@"+");
        [bFraction print];
        NSLog (@"=");
        resultFraction = [aFraction add: bFraction];
        [resultFraction print];
        NSLog(@"-----");
        
        // Subtraindo a 1a. com a 2a. fração
        [aFraction print];
        NSLog (@"-");
        [bFraction print];
        NSLog (@"=");
        resultFraction = [aFraction subtract: bFraction];
        [resultFraction print];
        NSLog(@"-----");
        
        // Multiplicando a 1a. com a 2a. fração
        [aFraction print];
        NSLog (@"*");
        [bFraction print];
        NSLog (@"=");
        resultFraction = [aFraction multiply: bFraction];
        [resultFraction print];
        NSLog(@"-----");
        
        // Dividindo a 1a. com a 2a. fração
        [aFraction print];
        NSLog (@"/");
        [bFraction print];
        NSLog (@"=");
        resultFraction = [aFraction divide: bFraction];
        [resultFraction print];
        NSLog(@"-----");
    }
    return 0;
}
