//
//  main.m
//  Programa_8-2
//
//  Created by Marcos Artur da Costa Cabral Filho on 24/09/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import "Rectangle.h"
#import "Square.h"
#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Rectangle *myRect = [[Rectangle alloc] init];
        
        [myRect setWidth: 5 andHeight: 8];
        
        NSLog (@"Rectangle: w = %i, h = %i", myRect.width, myRect.height);
        NSLog (@"Area = %i, Perimeter = %i", [myRect area], [myRect perimeter]);
        
        Square *mySquare = [[Square alloc] init];
        
        [mySquare setSide: 5];
        
        NSLog (@"Square s = %i", [mySquare side]);
        NSLog (@"Area = %i, Perimeter = %i", [mySquare area], [mySquare perimeter]);
    }
    return 0;
}
