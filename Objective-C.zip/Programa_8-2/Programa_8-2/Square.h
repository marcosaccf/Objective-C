//
//  Square.h
//  Programa_8-3
//
//  Created by Marcos Artur da Costa Cabral Filho on 24/09/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import "Rectangle.h"

@interface Square : Rectangle

-(void) setSide: (int) s;
-(int) side;

@end
