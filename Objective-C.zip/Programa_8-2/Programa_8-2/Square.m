//
//  Square.m
//  Programa_8-2
//
//  Created by Marcos Artur da Costa Cabral Filho on 24/09/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import "Square.h"

@implementation Square: Rectangle

-(void) setSide:(int) s
{
    [self setWidth: s andHeight: s];
}

-(int) side
{
    return self.width;
}

@end
