//
//  complex.m
//  Exerc_7-6
//
//  Created by Marcos Artur da Costa Cabral Filho on 24/09/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import "complex.h"

@implementation Complex;

@synthesize real, imaginary;

-(void) print
{
    printf("(%g + %gi)", real, imaginary);
}

-(void) setR: (double) r im: (double) i
{
    real = r;
    imaginary = i;
}

-(Complex *) add: (Complex *) complexNum
{
    // Para somar dois números complexos
    // (a + bi) + (c + di) = (a + c) + (b + d)i
    Complex *result = [[Complex alloc] init];
    result = complexNum;
    result.real += real;
    result.imaginary += imaginary;
    return result;
}

@end
