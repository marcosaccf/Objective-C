//
//  complex.h
//  Exerc_7-6
//
//  Created by Marcos Artur da Costa Cabral Filho on 24/09/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Complex : NSObject

@property double real, imaginary;

-(void) setR: (double) r im: (double) i;
-(void) print;
-(Complex *) add: (Complex *) complexNum;

@end
