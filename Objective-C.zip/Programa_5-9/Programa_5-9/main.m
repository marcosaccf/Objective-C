//
//  main.m
//  Programa_5-9 - Programa para inverter os dígitos de um número
//
//  Created by Marcos Artur da Costa Cabral Filho on 29/02/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        int number, right_digit;
        
        NSLog(@"Enter your number.");
        scanf ("%i", &number);
        
        do {
            right_digit = number % 10;
            printf ("%i", right_digit);
            number /= 10;
        }
        while ( number != 0 );
        printf ("\n");
    }
    return 0;
}
