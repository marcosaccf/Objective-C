//
//  main.m
//  Exerc_6-4 - Calculadora RPN
//
//  Created by Marcos Artur da Costa Cabral Filho on 30/04/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Calculator: NSObject

// métodos do acumulador
-(void) setAccumulator: (double) value;
-(void) clear;
-(double) accumulator;

// métodos aritméticos
-(void) add: (double) value;
-(void) subtract: (double) value;
-(void) multiply: (double) value;
-(void) divide: (double) value;
@end

@implementation Calculator
{
    double accumulator;
}

-(void) setAccumulator: (double) value
{
    accumulator = value;
}

-(void) clear
{
    accumulator = 0;
}

-(double) accumulator
{
    return accumulator;
}

-(void) add: (double) value
{
    accumulator += value;
}

-(void) subtract: (double) value
{
    accumulator -= value;
}

-(void) multiply: (double) value
{
    accumulator *= value;
}

-(void) divide: (double) value
{
    if (value != 0)
        accumulator /= value;
    else {
        NSLog (@"Division by zero.");
        accumulator = NAN;
    }
}
@end

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        double value1 = 0;
        char operator;
        Calculator *deskCalc = [[Calculator alloc] init];
        
        [deskCalc clear];
        while ( operator != 'E' && operator != 'e') {
            NSLog (@"Type in your expression: (numero operador):");
            scanf ("%lf %c", &value1, &operator);
        
            switch ( operator ) {
                case 'S':
                case 's':
                    [deskCalc setAccumulator : value1];
                    break;
                case '+':
                    [deskCalc add: value1];
                    break;
                case '-':
                    [deskCalc subtract: value1];
                    break;
                case '*':
                case 'x':
                case 'X':
                    [deskCalc multiply: value1];
                    break;
                case '/':
                    [deskCalc divide: value1];
                    break;
                case 'E':
                case 'e':
                    break;
                default:
                    NSLog (@"Unknown operator.");
                    [deskCalc clear];
                    break;
            }
        
            NSLog(@"%.2f", [deskCalc accumulator]);
        }
        NSLog(@"Fim dos calculos.");
    }
    return 0;
}