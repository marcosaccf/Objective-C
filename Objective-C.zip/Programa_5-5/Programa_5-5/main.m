//
//  main.m
//  Programa_5-5
//
//  Created by Marcos Artur da Costa Cabral Filho on 28/02/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        int n, number, triangularNumber, counter;
        
        for ( counter = 1; counter <= 5; ++counter ) {
            NSLog (@"What triangular number do you want?");
            scanf ("%i", &number);
            
            triangularNumber = 0;
            
            for ( n = 1; n <= number; ++n )
                triangularNumber += n;
            
            NSLog (@"Triangular number %i is %i", number, triangularNumber);
        }
    }
    return 0;
}
