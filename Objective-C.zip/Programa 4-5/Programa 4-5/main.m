//
//  main.m
//  Programa 4-5 - Conversões básicas em Objective-C
//
//  Created by Marcos Artur da Costa Cabral Filho on 07/01/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        float f1 = 123.125, f2;
        int i1, i2 = -150;
        
        i1 = f1;    // conversão de ponto flutuante para inteiro
        NSLog(@"%f assigned to an int produces %i", f1, i1);
        
        f1 = i2;    // conversão inteiro para ponto flutuante
        NSLog(@"%i assigned to a float produces %f", i2, f1);
        
        f1 = i2 / 100;  // inteiro dividido por inteiro
        NSLog(@"%i divided by 100 produces %f", i2, f1);
        
        f2 = i2 / 100.0;    // inteiro dividido por float
        NSLog(@"%i divided by 100.0 produces %f", i2, f2);
        
        f2 = (float) i2 / 100;  // operador de conversão de tipo
        NSLog(@"(float) %i divided by 100 produces %f", i2, f2);
    }
    return 0;
}
