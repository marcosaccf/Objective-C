//
//  main.m
//  exerc2-2
//
//  Created by Marcos Artur da Costa Cabral Filho on 06/12/15.
//  Copyright © 2015 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSLog(@"Em Objective-C, as letras minúsculas têm significado.");
        NSLog(@"main é onde a execução do programa começa.");
        NSLog(@"Chaves de abertura e fechamento cercam as instruções de programa \nem uma rotina.");
        NSLog(@"Todas as instruções de programa devem ser terminadas por um \nponto e vírgula.");
    }
    return 0;
}
