//
//  main.m
//  Exerc_6-1
//
//  Created by Marcos Artur da Costa Cabral Filho on 29/04/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        int valor1, valor2;
        
        NSLog (@"Entre com o valor do dividendo: ");
        scanf ("%i", &valor1);
        NSLog (@"Entre com o valor do divisor: ");
        scanf ("%i", &valor2);
        if ( valor1 % valor2 == 0 )
            NSLog (@"%i e divisivel por %i", valor1, valor2);
        else
            NSLog (@"%i NAO e divisivel por %i", valor1, valor2);
    }
    return 0;
}
