//
//  main.m
//  Exerc_5-3 - Programa para calcular fatorial
//
//  Created by Marcos Artur da Costa Cabral Filho on 29/02/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        int n, fatorial = 1;
        
        for ( n = 1; n <= 10; ++n ) {
            fatorial *= n;
            NSLog(@"%2i  %7i", n, fatorial);
        }
    }
    return 0;
}
