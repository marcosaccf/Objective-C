//
//  main.m
//  Exerc_4-5
//
//  Created by Marcos Artur da Costa Cabral Filho on 07/01/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        double result;
        
        result = (3.31e-8 + 2.01e-7) / (7.16e-6 + 2.01e-8);
        NSLog (@"O resultado da expressão é: %g", result);
    }
    return 0;
}
