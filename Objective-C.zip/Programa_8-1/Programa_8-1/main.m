//
//  main.m
//  Programa_8-1 - Exemplo simples para ilustrar herança
//
//  Created by Marcos Artur da Costa Cabral Filho on 24/09/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

// Declaração e definição de ClassA

@interface ClassA: NSObject
{
    int x;
}

-(void) initVar;
@end

@implementation ClassA
-(void) initVar
{
    x = 100;
}
@end

// Declaração e definição de ClassB

@interface ClassB: ClassA
-(void) printVar;
@end

@implementation ClassB
-(void) printVar;
{
    NSLog (@"x = %i", x);
}
@end

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        ClassB *b = [[ClassB alloc] init];
        
        [b initVar];    // usará método herdado
        [b printVar];   // revela o valor de x
    }
    return 0;
}
