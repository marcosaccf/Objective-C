//
//  Carro.h
//  OlaObjectiveC
//
//  Created by Marcos Artur da Costa Cabral Filho on 15/06/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Carro : NSObject {
    NSString *nome;
    int ano;
}
-(void) setNome:(NSString*)_nome;
-(NSString *) getNome;
-(void) setAno: (int)_ano;
-(int) getAno;
@end
