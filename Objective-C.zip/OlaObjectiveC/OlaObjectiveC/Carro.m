//
//  Carro.m
//  OlaObjectiveC
//
//  Created by Marcos Artur da Costa Cabral Filho on 15/06/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import "Carro.h"

@implementation Carro
- (void) setNome:(NSString*)_nome {
    nome = _nome;
}
- (NSString *) getNome {
    return nome;
}
- (void) setAno:(int)_ano {
    ano = _ano;
}
- (int) getAno {
    return ano;
}
@end
