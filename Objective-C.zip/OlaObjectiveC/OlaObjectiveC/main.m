//
//  main.m
//  OlaObjectiveC
//
//  Created by Marcos Artur da Costa Cabral Filho on 06/06/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World!");
        
        NSString *s = @"String aqui";
        int numero = 7;
        double decimal = 12.5;
        NSLog(@"Texto: %@, número inteiro: %d, número decimal: %f", s, numero, decimal);
    }
    return 0;
}
