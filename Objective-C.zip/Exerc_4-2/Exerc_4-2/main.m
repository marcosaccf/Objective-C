//
//  main.m
//  Exerc_4-2
//
//  Created by Marcos Artur da Costa Cabral Filho on 07/01/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        float C, F = 27.0;
        
        C = (F - 32) / 1.8;
        NSLog (@"27 graus Fahrenheit = %f graus Celsius", C);
    }
    return 0;
}
