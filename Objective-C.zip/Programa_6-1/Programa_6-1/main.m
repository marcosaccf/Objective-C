//
//  main.m
//  Programa_6-1 - Calcula o valor absoluto de um inteiro
//
//  Created by Marcos Artur da Costa Cabral Filho on 01/03/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        int number;
        
        NSLog(@"Type in your number: ");
        scanf("%i", &number);
        
        if ( number < 0 )
        number = -number;
        
        NSLog (@"The absolute value is %i", number);
    }
    return 0;
}
