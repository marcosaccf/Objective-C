//
//  main.m
//  Programa_6-3 - Programa para determinar se um número é par ou ímpar
//
//  Created by Marcos Artur da Costa Cabral Filho on 05/03/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World!");
    }
    return 0;
}
