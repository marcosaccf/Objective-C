//  Programa para calcular o 200º número triangular
//  Introdução da instrução for
//
//  Created by Marcos Artur da Costa Cabral Filho on 18/08/20.
//  Copyright © 2020 Curso IOS. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        int n, triangularNumber;
        
        triangularNumber = 0;
        for ( n = 1; n <= 200; n = n + 1 )
            triangularNumber += n;
        
        NSLog (@"The 200th triangular number is %i", triangularNumber);
    }
    return 0;
}
