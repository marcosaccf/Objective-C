//
//  main.m
//  prog3-1 - Programa simples para trabalhar com frações
//
//  Created by Marcos Artur da Costa Cabral Filho on 20/07/20.
//  Copyright © 2020 Curso IOS. All rights reserved.
//

#import <Foundation/Foundation.h>

int main (int argc, const char *argv[])
{
 @autoreleasepool {
     int numerator = 
 }
    return 0;
}
