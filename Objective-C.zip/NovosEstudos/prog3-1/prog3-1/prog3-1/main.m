//
//  main.m
//  prog3-1 - Programa simples para trabalhar com frações - versão classe
//
//  Created by Marcos Artur da Costa Cabral Filho on 21/07/20.
//  Copyright © 2020 Curso IOS. All rights reserved.
//

#import <Foundation/Foundation.h>

//---- seção @interface ----

@interface Fraction: NSObject

-(void) print;
-(void) setNumerator: (int) n;
-(void) setDenominator: (int) d;

@end

//---- seção @implementation ----

@implementation Fraction
{
    int numerator;
    int denominator;
}
-(void) print
{
    NSLog (@"%i/%i", numerator, denominator);
}

-(void) setNumerator: (int) n
{
    numerator = n;
}

-(void) setDenominator: (int) d
{
    denominator = d;
}

@end

//---- seção de programa ----

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Fraction *myFraction;
        
        // Cria uma instância de Fraction
        
        myFraction = [Fraction alloc];
        myFraction = [myFraction init];
        
        // Define a fração em 1/3
        
        [myFraction setNumerator: 1];
        [myFraction setDenominator: 3];
        
        // Exibe a fração usando o método print
        
        NSLog (@"The value of myFracton is:");
        [myFraction print];
    }
    return 0;
}
