//
//  main.m
//  prog3-3 - Programa para trabalhar com frações - continuação
//
//  Created by Marcos Artur da Costa Cabral Filho on 21/07/20.
//  Copyright © 2020 Curso IOS. All rights reserved.
//

#import <Foundation/Foundation.h>

//---- seção @interface ----

@interface Fraction: NSObject

-(void) print;
-(void) setNumerator: (int) n;
-(void) setDenominator: (int) d;
-(int) numerator;
-(int) denominator;

@end

//---- seção @implementation ----

@implementation Fraction
{
    int numerator;
    int denominator;
}

-(void) print
{
    NSLog (@"%i/%i", numerator, denominator);
}

-(void) setNumerator: (int) n
{
    numerator = n;
}

-(void) setDenominator: (int) d
{
    denominator = d;
}

-(int) numerator
{
    return numerator;
}

-(int) denominator
{
    return denominator;
}

@end

//---- seção de programa ----
    
int main(int argc, const char * argv[]) {
    @autoreleasepool {
        
        Fraction *frac1 = [[Fraction alloc] init];
        Fraction *frac2 = [[Fraction alloc] init];
        
        // Define a 1a fração como 2/3
        
        [frac1 setNumerator: 2];
        [frac1 setDenominator: 3];
        
        // Define a 2a fração como 3/7
        
        [frac2 setNumerator: 3];
        [frac2 setDenominator: 7];
        
        // Exibe as frações
        
        NSLog(@"First fraction is:");
        [frac1 print];
        
        NSLog (@"Second fraction is:");
        [frac2 print];
        
        // Exibe as frações usando nossos dois métodos
        
        NSLog (@"The value of frac1 is: %i/%i",
               [frac1 numerator], [frac1 denominator]);
        
        NSLog (@"The value of frac2 is: %i/%i",
        [frac2 numerator], [frac2 denominator]);
    }
    return 0;
}
