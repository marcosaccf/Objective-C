//
//  main.m
//  Programa_5-1 - Programa para calcular o oitavo número triangular
//
//  Created by Marcos Artur da Costa Cabral Filho on 31/01/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        int triangularNumber;
        
        triangularNumber = 1 + 2 + 3 + 4 + 5 + 6 + 7 + 8;
        
        NSLog(@"The eight triangular number is %i", triangularNumber);
    }
    return 0;
}
