//
//  main.m
//  Exerc_4-10
//
//  Created by Marcos Artur da Costa Cabral Filho on 30/01/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Calculator: NSObject

// métodos do acumulador
-(void) setAccumulator: (double) value;
-(void) clear;
-(double) accumulator;

// métodos aritméticos
-(double) add: (double) value;
-(double) subtract: (double) value;
-(double) multiply: (double) value;
-(double) divide: (double) value;
-(double) changeSign;   // muda o sinal do acumulador
-(double) reciprocal;   // 1/acumulador
-(double) xSquared;     // acumulador ao quadrado

// métodos de memória
-(double) memoryClear;  // limpa a memória
-(double) memoryStore;  // define a memória com o acumulador
-(double) memoryRecall; // define o acumulador com a memória
-(double) memoryAdd: (double) value;    // adiciona value na memória
-(double) memorySubtract: (double) value;  // subtrai value da memória
@end

@implementation Calculator
{
    double accumulator;
    double memory;
}

-(void) setAccumulator:(double)value
{
    accumulator = value;
}

-(void) clear
{
    accumulator = 0;
}

-(double) accumulator
{
    return accumulator;
}

-(double) add:(double) value
{
    accumulator += value;
    return accumulator;
}

-(double) subtract:(double) value
{
    accumulator -= value;
    return accumulator;
}

-(double) multiply:(double) value
{
    accumulator *= value;
    return accumulator;
}

-(double) divide:(double) value
{
    accumulator /= value;
    return accumulator;
}

-(double) changeSign
{
    accumulator = - accumulator;
    return accumulator;
}

-(double) reciprocal
{
    accumulator = 1 / accumulator;
    return accumulator;
}

-(double) xSquared
{
    accumulator = accumulator * accumulator;
    return accumulator;
}

-(double) memoryClear
{
    memory = 0;
    return accumulator;
}

-(double) memoryStore
{
    memory = accumulator;
    return accumulator;
}

-(double) memoryRecall;
{
    accumulator = memory;
    return accumulator;
}

-(double) memoryAdd:(double) value
{
    memory += value;
    return accumulator;
}

-(double) memorySubtract: (double) value
{
    memory -= value;
    return accumulator;
}
@end

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Calculator *deskCalc = [[Calculator alloc] init];
        
        [deskCalc setAccumulator: 100.0];
        NSLog (@"Set = 100. The result is %g", [deskCalc accumulator]);
        [deskCalc add: 200.];
        NSLog (@"Add 200. The result is %g", [deskCalc accumulator]);
        [deskCalc divide: 15.0];
        NSLog (@"Divide by 15. The result is %g", [deskCalc accumulator]);
        [deskCalc subtract: 10.0];
        NSLog (@"Subtract 10. The result is %g", [deskCalc accumulator]);
        [deskCalc multiply: 5];
        NSLog (@"Multiply by 5. The result is %g", [deskCalc accumulator]);
        [deskCalc changeSign];
        NSLog(@"Change Sign. The resut is %g", [deskCalc accumulator]);
        [deskCalc reciprocal];
        NSLog(@"Reciprocal. The result is %g", [deskCalc accumulator]);
        [deskCalc xSquared];
        NSLog(@"Squared. The result is %g", [deskCalc accumulator]);
        [deskCalc memoryClear];
        NSLog(@"Clear memory. The result is %g", [deskCalc accumulator]);
        [deskCalc memoryStore];
        NSLog(@"Save memory. The result is %g", [deskCalc accumulator]);
        [deskCalc clear];
        NSLog(@"Clear. The result is %g", [deskCalc accumulator]);
        [deskCalc memoryRecall];
        NSLog(@"Recall memory. The result is %g", [deskCalc accumulator]);
        [deskCalc clear];
        NSLog(@"Clear. The result is %g", [deskCalc accumulator]);
        [deskCalc memoryAdd: 5];
        NSLog(@"Add 5 to memory. The result is %g", [deskCalc accumulator]);
        [deskCalc memoryRecall];
        NSLog(@"Recall memory. The result is %g", [deskCalc accumulator]);
        [deskCalc memorySubtract: 10];
        NSLog(@"Subtract 10 to memory. The result is %g", [deskCalc accumulator]);
        [deskCalc memoryRecall];
        NSLog(@"Recall memory. The result is %g", [deskCalc accumulator]);
    }
    return 0;
}