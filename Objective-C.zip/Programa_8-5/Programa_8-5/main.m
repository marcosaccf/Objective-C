//
//  main.m
//  Programa_8-5
//
//  Created by Marcos Artur da Costa Cabral Filho on 24/09/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import "Rectangle.h"
#import "XYPoint.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Rectangle *myRect = [[Rectangle alloc] init];
        XYPoint *myPoint = [[XYPoint alloc] init];
        
        [myPoint setX: 100 andY: 200];
        
        [myRect setWidth: 5 andHeight: 8];
        myRect.origin = myPoint;
        
        NSLog (@"Rectangle w = %i, h = %i", myRect.width, myRect.height);
        NSLog (@"Origin at (%i, %i)", myRect.origin.x, myRect.origin.y);
        NSLog (@"Area = %i, Perimeter = %i", [myRect area], [myRect perimeter]);
        [myPoint setX: 50 andY: 50];
        NSLog (@"New origin at (%i, %i)", myRect.origin.x, myRect.origin.y);
        
        XYPoint *theOrigin = myRect.origin;
        
        theOrigin.x = 200;
        theOrigin.y = 300;
        
        NSLog (@"New origin at (%i, %i)", myRect.origin.x, myRect.origin.y);
    }
    return 0;
}
