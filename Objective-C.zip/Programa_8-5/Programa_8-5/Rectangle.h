//
//  Rectangle.h
//  Programa_8-5
//
//  Created by Marcos Artur da Costa Cabral Filho on 24/09/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "XYPoint.h"

@interface Rectangle : NSObject

@property int width, height;

-(XYPoint *) origin;
-(void) setOrigin: (XYPoint *) pt;
-(void) setWidth: (int) w andHeight: (int) h;
-(int) area;
-(int) perimeter;

@end
