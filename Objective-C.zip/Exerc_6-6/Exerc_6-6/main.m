//
//  main.m
//  Exerc_6-6 - Imprime os nomes dos algarismos de um inteiro em inglês.
//
//  Created by Marcos Artur da Costa Cabral Filho on 30/04/16.
//  Copyright © 2016 Marcos Artur da Costa Cabral Filho. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        int number, right_digit, aux, num_zero;
        
        NSLog(@"Enter your integer:");
        scanf ("%d", &number);  // se for o caso, despreza o zero à esquerda
        
        if (number < 0)         // testa se negativo
        {
            number = -number;   // inverte o número, se for negativo
            printf("minus\n");  // imprime a palavra menos
        }
        
        if ( number > 0 ) {     // testa se positivo
            // conta o número de zeros à direita
            while ( number % 10 == 0) {
                number /= 10;
                num_zero += 1;
            }
            // inverte a ordem de todos os dígitos em "aux"
            while ( number != 0 ) {
                right_digit = number % 10;
                aux += right_digit;
                aux *= 10;
                number /= 10;
            }
            aux /= 10;
            // imprime o nome de cada dígito do novo número "aux"
            while ( aux != 0 ) {
                right_digit = aux % 10;
                switch ( right_digit ) {
                    case 9:
                        printf ("nine\n");
                        break;
                    case 8:
                        printf ("eight\n");
                        break;
                    case 7:
                        printf ("seven\n");
                        break;
                    case 6:
                        printf ("six\n");
                        break;
                    case 5:
                        printf ("five\n");
                        break;
                    case 4:
                        printf ("four\n");
                        break;
                    case 3:
                        printf ("three\n");
                        break;
                    case 2:
                        printf ("two\n");
                        break;
                    case 1:
                        printf ("one\n");
                        break;
                    case 0:
                        printf ("zero\n");
                        break;
                    default:
                        printf("Unknown input");
                        break;
                }
                aux /= 10;
            }
            // imprime tantas palavras zero quantos forem os dígitos à direita
            for (; num_zero > 0; --num_zero) {
                printf ("zero\n");
            }
        }
        // imprime zero se o número digitado foi 0
        else
            printf ("zero\n");
    }
    return 0;
}
