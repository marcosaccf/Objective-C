//
//  InstaTwitTests.h
//  InstaTwitTests
//
//  Created by Paul Pilone on 4/5/13.
//  Copyright (c) 2013 Element 84, LLC. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface InstaTwitTests : SenTestCase

@end
