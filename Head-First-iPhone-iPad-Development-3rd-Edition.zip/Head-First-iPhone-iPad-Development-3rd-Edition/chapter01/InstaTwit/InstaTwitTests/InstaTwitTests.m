//
//  InstaTwitTests.m
//  InstaTwitTests
//
//  Created by Paul Pilone on 4/5/13.
//  Copyright (c) 2013 Element 84, LLC. All rights reserved.
//

#import "InstaTwitTests.h"

@implementation InstaTwitTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in InstaTwitTests");
}

@end
