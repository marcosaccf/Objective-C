//
//  MarcoPolloTests.h
//  MarcoPolloTests
//
//  Created by Dan Pilone on 10/9/12.
//  Copyright (c) 2012 Element 84, LLC. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface MarcoPolloTests : SenTestCase

@end
