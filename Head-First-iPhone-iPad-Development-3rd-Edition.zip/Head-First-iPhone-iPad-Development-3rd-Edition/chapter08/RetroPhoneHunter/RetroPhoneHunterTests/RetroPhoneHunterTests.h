//
//  RetroPhoneHunterTests.h
//  RetroPhoneHunterTests
//
//  Created by Paul Pilone on 5/5/13.
//  Copyright (c) 2013 Element 84, LLC. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface RetroPhoneHunterTests : SenTestCase

@end
