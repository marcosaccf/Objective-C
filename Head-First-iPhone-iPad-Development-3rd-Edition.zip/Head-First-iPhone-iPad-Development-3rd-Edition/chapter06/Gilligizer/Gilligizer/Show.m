//
//  Show.m
//  Gilligizer
//
//  Created by Paul Pilone on 4/23/13.
//  Copyright (c) 2013 Element 84, LLC. All rights reserved.
//

#import "Show.h"


@implementation Show

@dynamic title;
@dynamic desc;
@dynamic showTime;
@dynamic episodeID;
@dynamic firstRun;

@end
