//
//  ViewController.swift
//  PrimeiroApp
//
//  Created by Marcos Artur da Costa Cabral Filho on 08/09/17.
//  Copyright © 2017 Curso IOS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("Meu primeiro App")
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

