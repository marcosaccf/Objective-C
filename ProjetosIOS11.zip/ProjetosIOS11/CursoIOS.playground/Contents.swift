//: Playground - noun: a place where people can play

import UIKit

// Arrays
var nomes = ["Marcos", "Letícia", "Mariana"]

print( nomes[0] )

var nomesString: [String]
var numeros: [Int] = []

numeros.append(20)

numeros.append(400)

print( numeros )

nomesString = ["Jamilton"]

nomesString += ["Letícia"]

nomesString.append("Mariana")

nomesString.remove(at: 0)

print( nomesString )

// Desafio

var frases: [String] = ["Ouviram do Ipiranga"]

frases += ["Às margens plácidas"]

frases.append("De um povo heróico")

print( frases )

