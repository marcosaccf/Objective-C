//
//  main.m
//  MarcoPollo
//
//  Created by Marcos Artur da Costa Cabral Filho on 06/06/2018.
//  Copyright © 2018 Curso IOS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
