//
//  ViewController.h
//  MarcoPollo
//
//  Created by Marcos Artur da Costa Cabral Filho on 06/06/2018.
//  Copyright © 2018 Curso IOS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextView *tweetTextView;

- (IBAction)enviarButtonPressed:(id)sender;

@end

