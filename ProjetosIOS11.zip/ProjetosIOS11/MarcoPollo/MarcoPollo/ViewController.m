//
//  ViewController.m
//  MarcoPollo
//
//  Created by Marcos Artur da Costa Cabral Filho on 06/06/2018.
//  Copyright © 2018 Curso IOS. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)enviarButtonPressed:(id)sender {
    NSLog(@"Enviar button pressed!");
}
@end
