//
//  AppDelegate.h
//  MarcoPollo
//
//  Created by Marcos Artur da Costa Cabral Filho on 06/06/2018.
//  Copyright © 2018 Curso IOS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

